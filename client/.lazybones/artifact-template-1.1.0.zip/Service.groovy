package ${project_package}

import griffon.core.artifact.GriffonService
import griffon.metadata.ArtifactProviderFor

@ArtifactProviderFor(GriffonService)
class ${project_class_name}Service {

}